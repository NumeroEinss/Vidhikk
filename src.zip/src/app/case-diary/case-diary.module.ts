import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CaseDiaryRoutingModule } from './case-diary-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CaseDiaryRoutingModule
  ]
})
export class CaseDiaryModule { }
