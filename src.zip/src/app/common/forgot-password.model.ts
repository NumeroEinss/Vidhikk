export class forgotModel {
  mobile: string = '';
  email: string = '';
  otp: string = '';
  question: string = '';
  answer: string = '';
}

export class forgotModel2 {
  setPassword: string = '';
  confirmPassword: string = '';
}

