export class SignUpModel {
    mobile: string = "";
    otp: string = "";
}

export class SignUpModel2 {
    orgainization: string = "";
    fullName: string = "";
    fatherName: string = "";
    address: string = "";
    state: string = "";
    city: string = "";
    mobile: string = "";
    email: string = "";
    stateBar: string = "";
    courtName: string = "";
    licenseNo: string = "";
    practiceYear: string = "";
    practiceField: string = "";
    question: string = '';
    answer: string = '';
    question2: string = '';
    answer2: string = '';
}

