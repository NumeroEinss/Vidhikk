export class resetModel{
     oldPassword:string='';
     setNewPassword:string='';
     confirmNewPassword:string='';
     question:string='';
     answer:string='';
}