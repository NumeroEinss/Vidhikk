import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CaseLawListComponent } from './case-law-list/case-law-list.component';

const routes: Routes = [
  {
    path: 'cases',
    component: CaseLawListComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CaseLawRoutingModule { }
