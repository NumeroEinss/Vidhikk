import { Component } from '@angular/core';

@Component({
  selector: 'app-case-law-list',
  templateUrl: './case-law-list.component.html',
  styleUrl: './case-law-list.component.scss'
})
export class CaseLawListComponent {

}
